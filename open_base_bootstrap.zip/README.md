# Open Base — Free & Legal Data + Compute Bootstrap

This starter kit helps you begin building a **free (as in beer) / open (as in license)** knowledge base—ethically and within providers’ Terms of Service.

**What you get**
- `config.yaml` — choose datasets and storage folders.
- `manifest.yaml` — curated, *reasonable-size* starter datasets with verified URLs.
- `fetch.py` — resumable, checksum-aware downloader with logs and metadata.
- `index_text.py` — optional FTS5 (SQLite) text indexer for extracted plaintext.
- `.github/workflows/sync.yml` — optional weekly sync for a **public GitHub repo** (uses free Actions minutes) — designed to fetch *manifests & metadata only* by default.
- `requirements.txt` — minimal Python deps.
- `LICENSE` — MIT.

> ⚖️ **Legal & ethical**: Only download datasets that are open-licensed and offered for bulk access. Respect robots.txt, rate limits, and dataset-specific terms. Do **not** create multiple accounts to bypass provider limits; that violates ToS.

## Quick start (local)
```bash
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python fetch.py --config config.yaml --out ./data
```
The script will create `data/<dataset>/...` and a `metadata/index.jsonl` file with file hashes & provenance.

## Small-to-large path
1) Start with **Simple Wikipedia**, **OpenAlex slices**, and **Geofabrik regional OSM** (hundreds of MB to a few GB).
2) Add **Common Crawl indices** (no raw WARC at first), **Data Commons** (API snapshots).
3) Graduate to **Copernicus Sentinel subsets** or **Landsat tiles** if you need geospatial.

## Optional: GitHub Actions (metadata-only)
If you host this repo publicly on GitHub, the included workflow can **periodically refresh manifests and checksums** (no heavy data). It writes JSONL under `metadata/` and commits the diff. Public repos get free Actions minutes.

---
**You own the keys**: Configure any S3-compatible bucket (e.g., Cloudflare R2 free tier) using `R2_*` env vars if you wish to push artifacts (off by default).
