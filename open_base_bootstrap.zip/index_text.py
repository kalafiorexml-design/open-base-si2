#!/usr/bin/env python3
"""
Build a lightweight full-text index (SQLite FTS5) from plaintext files.
Usage:
  python index_text.py --root ./data/simple_wikipedia/extracted --db ./data/fts.sqlite
"""
import argparse, os, sqlite3, pathlib, glob, hashlib

def ensure_db(db):
    con = sqlite3.connect(db)
    con.execute("PRAGMA journal_mode=WAL;")
    con.execute("CREATE VIRTUAL TABLE IF NOT EXISTS docs USING fts5(path, content);")
    return con

def iter_text_files(root):
    for path in glob.glob(os.path.join(root, "**/*.txt"), recursive=True):
        yield path

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True, help="folder with plaintext (.txt) files")
    ap.add_argument("--db", required=True, help="sqlite db path")
    args = ap.parse_args()

    con = ensure_db(args.db)
    cur = con.cursor()
    n=0
    for p in iter_text_files(args.root):
        with open(p, "r", errors="ignore") as f:
            txt = f.read()
        cur.execute("INSERT INTO docs(path, content) VALUES(?,?)", (p, txt))
        n+=1
        if n%100==0:
            con.commit()
            print(f"Indexed {n} files...")
    con.commit()
    print(f"Indexed total: {n}")

if __name__ == "__main__":
    main()
