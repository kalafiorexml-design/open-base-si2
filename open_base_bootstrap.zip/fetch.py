#!/usr/bin/env python3
import argparse, json, os, sys, time, hashlib, pathlib, re
import requests
from urllib.parse import urlparse
from tqdm import tqdm
import yaml
import xxhash

CHUNK = 1024 * 1024

def safe_name(url: str) -> str:
    path = urlparse(url).path
    name = os.path.basename(path) or "index.html"
    # Keep query hint to avoid collisions
    q = urlparse(url).query.replace("=", "_").replace("&", "_")
    if q:
        name = f"{name}.{q[:50]}"
    return name

def ensure_dir(p):
    os.makedirs(p, exist_ok=True)

def hash_file(path):
    h = hashlib.sha256()
    hx = xxhash.xxh64()
    with open(path, "rb") as f:
        while True:
            b = f.read(CHUNK)
            if not b: break
            h.update(b); hx.update(b)
    return {"sha256": h.hexdigest(), "xxh64": hx.hexdigest(), "bytes": os.path.getsize(path)}

def head_size(url, timeout=20):
    try:
        r = requests.head(url, timeout=timeout, allow_redirects=True)
        if "content-length" in r.headers:
            return int(r.headers["content-length"])
    except Exception:
        return None
    return None

def download(url, out_path):
    temp = out_path + ".part"
    resume = os.path.exists(temp)
    headers = {}
    if resume:
        downloaded = os.path.getsize(temp)
        headers["Range"] = f"bytes={downloaded}-"
    with requests.get(url, stream=True, headers=headers, timeout=30) as r:
        r.raise_for_status()
        mode = "ab" if resume else "wb"
        total = int(r.headers.get("content-length") or 0)
        pbar = tqdm(total=total, unit="B", unit_scale=True, desc=os.path.basename(out_path))
        if resume: pbar.update(downloaded)
        with open(temp, mode) as f:
            for chunk in r.iter_content(chunk_size=CHUNK):
                if chunk:
                    f.write(chunk)
                    pbar.update(len(chunk))
        pbar.close()
    os.replace(temp, out_path)

def load_manifest(path):
    with open(path, "r") as f:
        return yaml.safe_load(f)

def should_run(cfg, key):
    return cfg.get("datasets", {}).get(key, False)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config.yaml")
    ap.add_argument("--manifest", default="manifest.yaml")
    ap.add_argument("--out", default="./data")
    args = ap.parse_args()

    with open(args.config, "r") as f:
        cfg = yaml.safe_load(f)
    manifest = load_manifest(args.manifest)

    root = pathlib.Path(args.out)
    ensure_dir(root)
    meta_dir = root / "metadata"
    ensure_dir(meta_dir)
    idx_path = meta_dir / "index.jsonl"

    for key, entry in manifest.items():
        if not should_run(cfg, key):
            continue
        droot = root / key
        ensure_dir(droot)
        for url in entry.get("urls", []):
            fname = safe_name(url)
            out_path = str(droot / fname)
            print(f"[{key}] GET {url}")
            try:
                download(url, out_path)
            except Exception as e:
                print(f"!! download failed: {e}", file=sys.stderr)
                continue
            h = hash_file(out_path)
            record = {
                "dataset": key,
                "url": url,
                "file": str(pathlib.Path(out_path).resolve()),
                "hash": h,
                "fetched_at": int(time.time()),
                "license": entry.get("license", ""),
                "notes": entry.get("notes",""),
                "type": entry.get("type","")
            }
            with open(idx_path, "a") as w:
                w.write(json.dumps(record, ensure_ascii=False) + "\n")
    print(f"Done. Index at: {idx_path}")

if __name__ == "__main__":
    main()
